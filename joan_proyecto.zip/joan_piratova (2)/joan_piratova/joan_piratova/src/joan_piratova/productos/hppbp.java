/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package joan_piratova.productos;

/**
 *
 * @author RPR-C80A404ES
 */
public class hppbp {
     private String nombre ;
     private String n_pedido ;
     private String dir_entrega ;
     private String telefono_del_u ;
     private int idhppbp;

    public hppbp(int idhppbp) {
        this.idhppbp = idhppbp;
    }
     

    public hppbp(String nombre, String n_pedido, String dir_entrega, String telefono_del_u) {
        this.nombre = nombre;
        this.n_pedido = n_pedido;
        this.dir_entrega = dir_entrega;
        this.telefono_del_u = telefono_del_u;
        
    }

    public void setIdhppbp(int idhppbp) {
        this.idhppbp = idhppbp;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setN_pedido(String n_pedido) {
        this.n_pedido = n_pedido;
    }

    public void setDir_entrega(String dir_entrega) {
        this.dir_entrega = dir_entrega;
    }

    public void setTelefono_del_u(String telefono_del_u) {
        this.telefono_del_u = telefono_del_u;
    }

    public int getIdhppbp() {
        return idhppbp;
    }
    

    public String getNombre() {
        return nombre;
    }

    public String getN_pedido() {
        return n_pedido;
    }

    public String getDir_entrega() {
        return dir_entrega;
    }

    public String getTelefono_del_u() {
        return telefono_del_u;
    }

    @Override
    public String toString() {
        return "hppbp{" + "nombre=" + nombre + ", n_pedido=" + n_pedido + ", dir_entrega=" + dir_entrega + ", telefono_del_u=" + telefono_del_u + ", idhppbp=" + idhppbp + '}';
    }

    
    
}
